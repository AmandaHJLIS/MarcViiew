import os

program_folder = os.path.dirname(os.path.abspath(__file__))
xml_file = os.path.join(program_folder, "wiitdb.xml")

with open(xml_file, "r", encoding="utf-8", errors="replace") as file:
    found_game = False

    for line in file:
        line = line.strip()

        if line.startswith("<game "):
            found_game = True
            print("FIRST GAME:")
            print(line)
            print()
            continue

        if found_game:
            print(line)

            if line == "</game>":
                break